<?php
include 'lessc.inc.php';

$lessc = new lessc;

$lessc->setFormatter( "compressed" );

$lessDir = 'style/less/';
$cssDir = 'style/css/';

$scanLess = scandir( $lessDir );

foreach ( $scanLess as $filename ) {
	if ($filename !== '.' && $filename !== '..') {
		$lessFile = $lessDir . $filename;
		$cssFile = $cssDir . str_replace( '.less', '.css', $filename );

		if ( file_exists( $lessFile ) ) {
			try {
				$lessc->checkedCompile( $lessFile, $cssFile );
			} catch ( Exception $e ) {
				echo 'lessphp fatal error: ' . $e->getMessage();
			}

		} else {
			echo 'less file doesn\'t exist: ' . $lessFile . '<br>';
		}
	}
}




function svg_helper($name){
  $file = 'pictures/'.$name.'.svg';
  if (file_exists($file)){
    return file_get_contents($file);
  } else {
    echo $name.'.svg doesn\'t exist.';
  }
}


 ?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style/css/style.css">
  </head>
  <body>
    <div class="background-container">
      <div class="first block"></div>
      <div class="second block">
        <div class="shape first"></div>
        <div class="shape second"></div>
        <div class="shape third"></div>
      </div>
    </div>
      <div class="logo-container">
        <?=svg_helper('logo');?>
        <h1>Avazz</h1>
      </div>


      <div class="content-block">
        <div class="block-header">
          <h3>Professionally coordinate ideas</h3>
        </div>
        <div class="content">
          Appropriatley disseminate viral collaboration an idea-sharing
        </div>
      </div>

      <div class="content-block1">
        <div class="block-header1">
          <h3>Produce compelling value</h3>
        </div>
        <div class="content1">
          Efficiently coordinate end-to-end strategy.
        </div>
      </div>

      <div class="content-blockc">
        <button>Continue</button>
        <div class="chevron-down">

        </div>
      </div>
  </body>
</html>
