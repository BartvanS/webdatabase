<?php 
include 'lessc.inc.php';

$lessc = new lessc;

$lessc->setFormatter( "compressed" );

$lessDir = 'style/less/';
$cssDir = 'style/css/';

$scanLess = scandir( $lessDir );

foreach ( $scanLess as $filename ) {
	if ($filename !== '.' && $filename !== '..') {
		$lessFile = $lessDir . $filename;
		$cssFile = $cssDir . str_replace( '.less', '.css', $filename );

		if ( file_exists( $lessFile ) ) {
			try {
				$lessc->checkedCompile( $lessFile, $cssFile );
			} catch ( Exception $e ) {
				echo 'lessphp fatal error: ' . $e->getMessage();
			}

		} else {
			echo 'less file doesn\'t exist: ' . $lessFile . '<br>';
		}
	}
}
?>
